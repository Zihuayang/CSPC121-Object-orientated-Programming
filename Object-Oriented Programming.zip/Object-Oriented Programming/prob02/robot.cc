#include "robot.h"
#include <iostream>
#include <string>
#include "cpputils/graphics/image.h"

void Robot::Draw(graphics::Image& my_image) {
  graphics::Image second_image;
  counter++;
  if (counter % 2 == 1) {
    second_image.Load(filename1_);
    location(my_image, second_image);
  } else if (counter % 2 == 0) {
    second_image.Load(filename2_);
    location(my_image, second_image);
  }
}

void Robot::location(graphics::Image& my_image, graphics::Image& second_image) {
  if (x_ <= my_image.GetWidth() && x_ >= 0 && y_ <= my_image.GetHeight() &&
      y_ >= 0) {
    for (int i = 0; i < second_image.GetWidth(); i++) {
      for (int j = 0; j < second_image.GetHeight(); j++) {
        my_image.SetColor(i + (x_ - (second_image.GetWidth() / 2)),
                          j + (y_ - (second_image.GetHeight() / 2)),
                          second_image.GetColor(i, j));
      }
    }
  }
}
