#ifndef ROBOT_H
#define ROBOT_H
#include "cpputils/graphics/image.h"

class Robot {
 public:
  Robot(std::string filename1, std::string filename2) {
    filename1_ = filename1;
    filename2_ = filename2;
  }

  int GetX() { return x_; }
  int GetY() { return y_; }

  void Draw(graphics::Image& my_image);
  void location(graphics::Image& my_image, graphics::Image& second_image);

  void SetPosition(int x, int y) {
    x_ = x;
    y_ = y;
  }

 private:
  int x_;
  int y_;
  int counter = 0;
  std::string filename1_;
  std::string filename2_;
};

#endif
