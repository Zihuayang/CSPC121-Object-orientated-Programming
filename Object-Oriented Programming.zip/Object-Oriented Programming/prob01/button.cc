// cmath is used for GetScaledChannel.
#include "button.h"
#include <cmath>
#include "cpputils/graphics/image.h"
// Don't forget to include button.h and cpputils/graphics/image.h.

// Use this to scale a color channel from the range (0, 255)
// to the range (0, 1).
double GetScaledChannel(int channel) {
  double scaled = channel / 255.;
  const double min = 0.03928;
  if (scaled <= min) {
    return scaled / 12.92;
  } else {
    return pow((scaled + .055) / 1.055, 2.4);
  }
}

// Implement the functions from button.h here.

double contrastRatio(graphics::Color color) {
  int red = color.Red();
  int green = color.Green();
  int blue = color.Blue();
  double red_ = GetScaledChannel(red);
  double green_ = GetScaledChannel(green);
  double blue_ = GetScaledChannel(blue);
  return .2126 * red_ + .7152 * green_ + .0722 * blue_;
}

double Button::GetContrastRatio() const {
  double contrast_ratio_ = 0;
  if (contrastRatio(text_color_) > contrastRatio(background_color_)) {
    contrast_ratio_ =
        (static_cast<double>((contrastRatio(text_color_) + 0.05) /
                             (contrastRatio(background_color_) + 0.05)));
  } else if (contrastRatio(text_color_) < contrastRatio(background_color_)) {
    contrast_ratio_ =
        (static_cast<double>((contrastRatio(background_color_) + 0.05) /
                             (contrastRatio(text_color_) + 0.05)));
  } else if (contrastRatio(text_color_) == contrastRatio(background_color_)) {
    contrast_ratio_ =
        (static_cast<double>((contrastRatio(background_color_) + 0.05) /
                             (contrastRatio(text_color_) + 0.05)));
  }
  return contrast_ratio_;
}

int ButtonWithMostContrast(const std::vector<Button>& buttons) {
  int largest = buttons[0].GetContrastRatio();
  int largestIndex = 0;

  for (int i = 1; i < buttons.size(); i++) {
    if (buttons[i].GetContrastRatio() > largest) {
      largest = buttons[i].GetContrastRatio();
      largestIndex = i;
    }
  }
  return largestIndex;
}
