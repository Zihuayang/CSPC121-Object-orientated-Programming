#include <iostream>
#include "math.h"

int main() {
  int x = factorial(5);
  std::cout << x << "\n";
  return 0;
}
