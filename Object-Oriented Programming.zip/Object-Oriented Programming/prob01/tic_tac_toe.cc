#include <iostream>
#include <vector>

int CheckGame(std::vector<std::vector<int>>& game) {
  for (int i = 0; i < 3; i++) {
    if (game[i][0] == game[i][1] && game[i][1] == game[i][2] &&
        game[i][0] != 0) {
      return game[i][0];
    }
  }
  for (int j = 0; j < 3; j++) {
    if (game[0][j] == game[1][j] && game[1][j] == game[2][j] &&
        game[0][j] != 0) {
      return game[0][j];
    }
  }
  if (game[0][2] == game[1][1] && game[1][1] == game[2][0] && game[0][2] != 0) {
    return game[0][2];
  }
  if (game[0][0] == game[1][1] && game[1][1] == game[2][2] && game[0][0] != 0) {
    return game[0][0];
  }

  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 3; j++) {
      if (game[i][j] == 0) {
        return 0;
      }
    }
  }
  return -1;
}
