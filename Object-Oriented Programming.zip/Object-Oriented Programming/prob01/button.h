#ifndef BUTTON_H
#define BUTTON_H
#include "cpputils/graphics/image.h"

class Button {
 public:
  Button(graphics::Color foreground, graphics::Color background) {
    text_color_ = foreground;
    background_color_ = background;
  }
  graphics::Color GetTextColor() const { return text_color_; }
  graphics::Color GetBackgroundColor() const { return background_color_; }
  double GetContrastRatio() const;

  bool IsAccessible() {
    bool result;
    if (GetContrastRatio() >= 4.5) {
      result = true;
    } else {
      result = false;
    }
    return result;
  }

 private:
  graphics::Color text_color_;
  graphics::Color background_color_;
  double contrast_ratio_;
};

int ButtonWithMostContrast(const std::vector<Button>& buttons);

#endif
