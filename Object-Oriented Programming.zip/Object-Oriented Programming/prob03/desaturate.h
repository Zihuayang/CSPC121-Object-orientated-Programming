#include "cpputils/graphics/image.h"

void Desaturate(graphics::Image& image);
