#include "desaturate.h"
using namespace std;

void Desaturate(graphics::Image& image) {
  int width = image.GetWidth();
  int height = image.GetHeight();
  int red, green, blue;
  for (int i = 0; i < width; i++) {
    for (int j = 0; j < height; j++) {
      red = image.GetRed(i, j);
      green = image.GetGreen(i, j);
      blue = image.GetBlue(i, j);
      image.SetRed(i, j, (red + blue + green) / 3);
      image.SetGreen(i, j, (red + blue + green) / 3);
      image.SetBlue(i, j, (red + blue + green) / 3);
    }
  }
}
